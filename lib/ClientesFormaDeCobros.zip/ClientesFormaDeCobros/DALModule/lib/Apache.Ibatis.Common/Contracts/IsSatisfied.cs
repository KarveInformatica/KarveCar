namespace Apache.Ibatis.Common.Contracts
{
    public delegate bool IsSatisfied();
}