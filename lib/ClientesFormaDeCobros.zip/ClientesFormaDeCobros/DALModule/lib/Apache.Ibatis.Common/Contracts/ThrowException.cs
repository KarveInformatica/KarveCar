namespace Apache.Ibatis.Common.Contracts
{
    public delegate void ThrowException(string message);
}