namespace Apache.Ibatis.Common.Contracts
{
    public delegate string GetErrorMessage();
}