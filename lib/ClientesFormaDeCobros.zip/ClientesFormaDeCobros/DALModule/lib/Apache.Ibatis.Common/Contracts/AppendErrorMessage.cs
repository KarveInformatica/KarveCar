namespace Apache.Ibatis.Common.Contracts
{
    public delegate void AppendErrorMessage(string message);
}