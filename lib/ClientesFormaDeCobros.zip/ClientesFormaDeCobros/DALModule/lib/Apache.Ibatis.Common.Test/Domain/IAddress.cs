

namespace Apache.Ibatis.Common.Test.Domain
{
    public interface IAddress : IBaseDomain
    {
        string Streetname { get; set; }
    } 
}
