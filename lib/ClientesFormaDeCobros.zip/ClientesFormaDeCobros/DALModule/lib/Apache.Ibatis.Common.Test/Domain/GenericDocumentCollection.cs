using System.Collections.Generic;

namespace Apache.Ibatis.Common.Test.Domain
{
    public class GenericDocumentCollection : List<Document>
    {
    }
}

