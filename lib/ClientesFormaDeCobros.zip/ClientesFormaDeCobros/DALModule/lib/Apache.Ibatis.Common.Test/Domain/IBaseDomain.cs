
using System;

namespace Apache.Ibatis.Common.Test.Domain
{
    public interface IBaseDomain
    {
        Guid Id { get; set; }
    } 

}
