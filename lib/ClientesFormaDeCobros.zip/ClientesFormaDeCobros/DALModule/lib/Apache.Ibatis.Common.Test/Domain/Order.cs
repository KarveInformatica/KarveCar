using System;

namespace Apache.Ibatis.Common.Test.Domain
{
	/// <summary>
	/// Summary description for Order.
	/// </summary>
	public class Order
	{
		private Order()
		{
		}
	}
}
