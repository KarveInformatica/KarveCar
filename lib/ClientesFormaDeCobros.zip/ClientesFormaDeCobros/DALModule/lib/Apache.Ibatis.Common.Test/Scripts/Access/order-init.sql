drop table ORDERS;

create table ORDERS
(
   [ORDER_ID]                       long                            not null,
   [ACCOUNT_ID]                     long                            not null,
   [ORDER_DATE]                     datetime,
   [ORDER_CARDTYPE]                 text(32),
   [ORDER_CARDNUMBER]               text(32),
   [ORDER_CARDEXPIRY]               text(32),
   [ORDER_STREET]                   text(32),
   [ORDER_CITY]                     text(32),
   [ORDER_PROVINCE]                 text(32),
   [ORDER_POSTALCODE]               text(32),
   [ORDER_FAVOURITELINEITEM]        long,
   constraint pkOrders
   primary key ([ORDER_ID])
);

INSERT INTO Orders VALUES (1, 1, '2003-02-15 8:15:00', 'VISA', '999999999999', '05/03', '11 This Street', 'Victoria', 'BC', 'C4B 4F4',2);
INSERT INTO Orders VALUES (2, 4, '2003-02-15 8:15:00', 'MC', '888888888888', '06/03', '222 That Street', 'Edmonton', 'AB', 'X4K 5Y4',1);
INSERT INTO Orders VALUES (3, 3, '2003-02-15 8:15:00', 'AMEX', '777777777777', '07/03', '333 Other Street', 'Regina', 'SK', 'Z4U 6Y4',2);
INSERT INTO Orders VALUES (4, 2, '2003-02-15 8:15:00', 'MC', '666666666666', '08/03', '444 His Street', 'Toronto', 'ON', 'K4U 3S4',1);
INSERT INTO Orders VALUES (5, 5, '2003-02-15 8:15:00', 'VISA', '555555555555', '09/03', '555 Her Street', 'Calgary', 'AB', 'J4J 7S4',2);
INSERT INTO Orders VALUES (6, 5, '2003-02-15 8:15:00', 'VISA', '999999999999', '10/03', '6 Their Street', 'Victoria', 'BC', 'T4H 9G4',1);
INSERT INTO Orders VALUES (7, 4, '2003-02-15 8:15:00', 'MC', '888888888888', '11/03', '77 Lucky Street', 'Edmonton', 'AB', 'R4A 0Z4',2);
INSERT INTO Orders VALUES (8, 3, '2003-02-15 8:15:00', 'AMEX', '777777777777', '12/03', '888 Our Street', 'Regina', 'SK', 'S4S 7G4',1);
INSERT INTO Orders VALUES (9, 2, '2003-02-15 8:15:00', 'MC', '666666666666', '01/04', '999 Your Street', 'Toronto', 'ON', 'G4D 9F4',2);
INSERT INTO Orders VALUES (10, 1, '2003-02-15 8:15:00', 'VISA', '555555555555', '02/04', '99 Some Street', 'Calgary', 'AB', 'W4G 7A4',1);

