﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Apache.Ibatis.DataMapper;
using DataAccessLayer.DataObjects;
using KarveCommon.Generic;
using System.Data;

namespace DataAccessLayer
{
    public class ChargeTypeDataAccessLayer: BaseDataMapper
    {
        private readonly string _id = "ChargeTypeDAL";
        private Type _dalType = typeof(ChargeTypeObject);
        public ChargeTypeDataAccessLayer()
        {
            base.Id = _id;
        }
        public override GenericObservableCollection GetItems()
        {
            ObservableCollection<ChargeTypeObject> dataCollection = new ObservableCollection<ChargeTypeObject>();
            QueryCopy(DataMapper, out dataCollection);
            GenericObservableCollection obs = new GenericObservableCollection();
            ObservableCollection<object> newCollection = new ObservableCollection<object>();
            foreach (var item in dataCollection)
            {
                newCollection.Add(item);
            }
            obs.GenericObsCollection = newCollection;
            return obs;
        }
        private void QueryCopy(IDataMapper mapper, out ObservableCollection<ChargeTypeObject> collection)
        {
            ICollection<ChargeTypeObject> banks = DataMapper.QueryForList<ChargeTypeObject>("Auxiliares.GetAllChargeType", null);
            collection = new ObservableCollection<ChargeTypeObject>();
            foreach (var bank in banks)
            {
                collection.Add(bank);
            }
        }

        public DataTable GetChargeObjects()
        {
            DataTable table = new DataTable();
            ICollection<ChargeTypeObject> charges = DataMapper.QueryForList<ChargeTypeObject>("Auxiliares.GetAllChargeType", null);
            table.Columns.Add(new DataColumn("Numero", typeof(long)));
            table.Columns.Add(new DataColumn("Nombre", typeof(string)));
            foreach (ChargeTypeObject item in charges)
            {
                var row = table.NewRow();
                row["Numero"] =  item.Numero;
                row["Nombre"] =  item.Nombre;
                table.Rows.Add(row);
            }
            return table;
        }

        public override void SetItems(GenericObservableCollection collection)
        {
            throw new NotImplementedException();
        }

        public override void StoreCollection<T>(ObservableCollection<T> collection)
        {
            throw new NotImplementedException();
        }

        public override void RemoveCollection<T>(ObservableCollection<T> collection)
        {
            throw new NotImplementedException();
        }
    }
}
