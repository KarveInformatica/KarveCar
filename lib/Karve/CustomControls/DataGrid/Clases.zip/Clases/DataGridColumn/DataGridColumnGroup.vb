﻿Imports Telerik.WinControls.UI

Public Class DataGridColumnGroup
    Inherits GridViewColumnGroup

End Class
