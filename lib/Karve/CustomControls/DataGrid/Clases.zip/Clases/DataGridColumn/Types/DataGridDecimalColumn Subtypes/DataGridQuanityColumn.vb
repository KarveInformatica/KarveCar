﻿Imports Karve.ConfiguracionApp

Public Class DataGridQuantityColumn
    Inherits DataGridDecimalColumn


    Public Sub New()
        NumeroDecimales = decimalesCantidad
    End Sub
End Class
