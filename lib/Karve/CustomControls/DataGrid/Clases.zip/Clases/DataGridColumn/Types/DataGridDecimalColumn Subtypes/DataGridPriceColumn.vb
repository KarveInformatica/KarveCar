﻿Imports Karve.ConfiguracionApp

Public Class DataGridPriceColumn
    Inherits DataGridDecimalColumn


    Public Sub New()
        NumeroDecimales = decimalesPrecios
    End Sub
End Class
