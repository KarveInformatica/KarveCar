﻿Imports Karve.ConfiguracionApp

Public Class DataGridPercentageColumn
    Inherits DataGridDecimalColumn


    Public Sub New()
        NumeroDecimales = decimalesPorcentaje
    End Sub
End Class
