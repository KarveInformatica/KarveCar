﻿Imports Karve.ConfiguracionApp

Public Class DataGridTotalColumn
    Inherits DataGridDecimalColumn


    Public Sub New()
        NumeroDecimales = decimalesTotales
    End Sub
End Class
