﻿using DataAccessLayer.DataObjects;

public class CompanyInfoViewModel
{
    public CompanyDto DataObject { set; get; }    
}